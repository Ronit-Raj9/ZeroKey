# @ronii/zerokey

Bootstrap CLI for configuring OpenCode to use your ZeroKey/AdShell hosted proxy.

## Usage

```bash
npx @ronii/zerokey init
```

This writes/updates OpenCode config under your user config directory and points the provider to the published default proxy.

## Override proxy URL

```bash
npx @ronii/zerokey init --proxy https://your-proxy.example.com
```

or set:

```bash
export ZEROKEY_PROXY_URL=https://your-proxy.example.com
npx @ronii/zerokey init
```

## Publish (maintainer)

From this folder:

```bash
npm login
npm publish --access public
```

## Notes

- Default proxy is read from `package.json` field `zerokey.defaultProxy`.
- Keep the proxy HTTPS and reachable publicly.
